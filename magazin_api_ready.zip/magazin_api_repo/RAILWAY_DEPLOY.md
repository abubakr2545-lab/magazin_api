# 🚂 Деплой на Railway - Пошаговая Инструкция

## 📋 Предварительные требования

✅ Аккаунт на [Railway.app](https://railway.app)  
✅ Git установлен на вашем компьютере  
✅ GitHub/GitLab аккаунт (опционально, но рекомендуется)

---

## 🚀 Способ 1: Деплой через Railway CLI (Рекомендуется)

### Шаг 1: Установка Railway CLI

Откройте PowerShell и выполните:

```powershell
# Установка через npm (если у вас установлен Node.js)
npm i -g @railway/cli

# ИЛИ скачайте с официального сайта:
# https://docs.railway.app/develop/cli#installing-the-cli
```

### Шаг 2: Инициализация Git (если еще не сделано)

```powershell
cd "c:\Users\Sherzod\Downloads\Telegram Desktop\иномов проект"

# Инициализация git
git init

# Добавление всех файлов
git add .

# Первый коммит
git commit -m "Initial commit for Railway deployment"
```

### Шаг 3: Вход в Railway

```powershell
railway login
```

Это откроет браузер для авторизации.

### Шаг 4: Инициализация Railway проекта

```powershell
# Создать новый проект
railway init

# Когда спросят название проекта, введите что-то вроде: clothing-store-api
```

### Шаг 5: Добавление PostgreSQL базы данных

```powershell
# Добавить PostgreSQL
railway add --database postgres
```

### Шаг 6: Установка переменных окружения

```powershell
# Установите переменные окружения
railway variables

# ИЛИ установите вручную через команды:
railway variables set SECRET_KEY="ваш-секретный-ключ-минимум-32-символа"
railway variables set ALGORITHM="HS256"
railway variables set ACCESS_TOKEN_EXPIRE_MINUTES="30"
railway variables set ALLOWED_ORIGINS="https://ваш-фронтенд.com"
```

Railway автоматически предоставит переменную `DATABASE_URL` для PostgreSQL!

### Шаг 7: Деплой!

```powershell
railway up
```

### Шаг 8: Получение URL вашего API

```powershell
railway domain
```

Это создаст публичный домен для вашего приложения!

---

## 🌐 Способ 2: Деплой через GitHub (Альтернатива)

### Шаг 1: Создайте репозиторий на GitHub

1. Идите на [GitHub](https://github.com) и создайте новый репозиторий
2. НЕ добавляйте README, .gitignore или лицензию

### Шаг 2: Загрузите код на GitHub

```powershell
cd "c:\Users\Sherzod\Downloads\Telegram Desktop\иномов проект"

# Инициализация Git (если еще не сделано)
git init

# Добавление всех файлов
git add .

# Коммит
git commit -m "Initial commit"

# Добавьте удаленный репозиторий (замените YOUR-USERNAME и YOUR-REPO)
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git

# Отправьте код
git branch -M main
git push -u origin main
```

### Шаг 3: Подключите GitHub к Railway

1. Зайдите на [Railway.app](https://railway.app)
2. Нажмите **"New Project"**
3. Выберите **"Deploy from GitHub repo"**
4. Выберите ваш репозиторий
5. Railway автоматически обнаружит ваше Python приложение!

### Шаг 4: Добавьте PostgreSQL

1. В вашем проекте Railway нажмите **"New"**
2. Выберите **"Database"** → **"Add PostgreSQL"**
3. Railway автоматически создаст переменную `DATABASE_URL`

### Шаг 5: Настройте переменные окружения

1. Перейдите в настройки вашего сервиса
2. Откройте вкладку **"Variables"**
3. Добавьте следующие переменные:

```
SECRET_KEY = ваш-секретный-ключ-минимум-32-символа
ALGORITHM = HS256
ACCESS_TOKEN_EXPIRE_MINUTES = 30
ALLOWED_ORIGINS = https://ваш-фронтенд.com
```

**ВАЖНО**: Для генерации безопасного SECRET_KEY:

```powershell
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Шаг 6: Настройка домена

1. Перейдите в **Settings** → **Networking**
2. Нажмите **"Generate Domain"**
3. Ваш API будет доступен по URL вида: `https://ваш-проект.railway.app`

---

## 🔧 Важные замечания

### 1. База данных SQLite → PostgreSQL

Ваш проект сейчас использует SQLite, но на Railway лучше использовать PostgreSQL. Railway предоставляет PostgreSQL бесплатно!

Переменная `DATABASE_URL` будет автоматически установлена Railway в формате:
```
postgresql://user:password@host:port/database
```

### 2. Миграция данных

Если у вас есть данные в локальной SQLite базе, которые нужно перенести:

```powershell
# Экспортируйте данные (пример для SQLite)
sqlite3 clothing_store.db .dump > backup.sql

# После деплоя подключитесь к PostgreSQL и импортируйте
# (это потребует конвертации SQL-запросов)
```

### 3. Проверка логов

```powershell
# Через CLI
railway logs

# Или в веб-интерфейсе Railway
```

### 4. Переменные окружения

Railway автоматически предоставляет:
- `PORT` - порт, на котором должно работать приложение
- `DATABASE_URL` - URL для подключения к PostgreSQL

---

## 📊 Мониторинг и управление

### Просмотр логов
```powershell
railway logs
```

### Перезапуск сервиса
```powershell
railway restart
```

### Открыть в браузере
```powershell
railway open
```

---

## 🆘 Возможные проблемы и решения

### Проблема: Ошибка при старте приложения

**Решение**: Проверьте логи:
```powershell
railway logs
```

### Проблема: Не могу подключиться к базе данных

**Решение**: Убедитесь, что переменная `DATABASE_URL` установлена:
```powershell
railway variables
```

### Проблема: CORS ошибки

**Решение**: Обновите `ALLOWED_ORIGINS` в переменных окружения Railway на ваш фронтенд URL.

---

## 🎯 Проверка деплоя

После деплоя проверьте:

1. **Health check**: `https://ваш-домен.railway.app/health`
2. **API документация**: `https://ваш-домен.railway.app/docs`
3. **ReDoc**: `https://ваш-домен.railway.app/redoc`

---

## 💰 Стоимость

Railway предоставляет:
- **$5 кредитов бесплатно** каждый месяц (без карты)
- **$500 часов выполнения** в месяц на бесплатном плане

Для большинства небольших проектов этого достаточно!

---

## 📚 Полезные ссылки

- [Railway Документация](https://docs.railway.app)
- [Railway CLI](https://docs.railway.app/develop/cli)
- [Railway Templates](https://railway.app/templates)

---

## ✅ Чеклист перед деплоем

- [ ] Все файлы добавлены в git
- [ ] `requirements.txt` актуален
- [ ] `.env` добавлен в `.gitignore` (НЕ пушьте .env на GitHub!)
- [ ] Сгенерирован безопасный `SECRET_KEY`
- [ ] Настроен `ALLOWED_ORIGINS` для вашего фронтенда
- [ ] База данных PostgreSQL добавлена в Railway
- [ ] Все переменные окружения установлены

---

**Удачи с деплоем! 🚀**
