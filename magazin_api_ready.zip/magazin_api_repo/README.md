# Магазин Одежды - FastAPI

REST API для онлайн-магазина одежды с управлением товарами, категориями и заказами.

## 🚀 Возможности

- ✅ **Категории** - иерархическая структура категорий товаров
- ✅ **Товары** - управление товарами с размерами, цветами и ценами
- ✅ **Аутентификация** - JWT авторизация пользователей
- ✅ **Заказы** - полный цикл обработки заказов
- ✅ **Поиск и фильтрация** - поиск товаров по различным критериям
- ✅ **Автоматическая документация** - Swagger UI и ReDoc

## 📋 Требования

- Python 3.8+
- pip

## 🛠 Установка

1. Клонируйте репозиторий или распакуйте проект
2. Создайте виртуальное окружение:
```bash
python -m venv venv
```

3. Активируйте виртуальное окружение:
```bash
# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

4. Установите зависимости:
```bash
pip install -r requirements.txt
```

5. Создайте файл `.env` на основе `.env.example`:
```bash
copy .env.example .env
```

6. Отредактируйте `.env` файл при необходимости

## 🚀 Запуск

```bash
python main.py
```

Или с помощью uvicorn:
```bash
uvicorn main:app --reload
```

API будет доступен по адресу: `http://localhost:8000`

## 📚 Документация API

После запуска сервера доступна автоматическая документация:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🔑 Использование API

### Регистрация пользователя

```bash
POST /auth/register
{
  "email": "user@example.com",
  "password": "password123",
  "full_name": "Иван Иванов"
}
```

### Вход

```bash
POST /auth/login
{
  "username": "user@example.com",
  "password": "password123"
}
```

### Создание категории

```bash
POST /categories
{
  "name": "Футболки",
  "description": "Мужские и женские футболки"
}
```

### Создание товара

```bash
POST /products
{
  "name": "Футболка базовая",
  "description": "Классическая футболка из хлопка",
  "price": 1500.00,
  "category_id": 1,
  "stock": 100,
  "sizes": ["S", "M", "L", "XL"],
  "colors": ["Черный", "Белый", "Синий"]
}
```

### Создание заказа

```bash
POST /orders
Authorization: Bearer <token>
{
  "items": [
    {
      "product_id": 1,
      "quantity": 2,
      "size": "M",
      "color": "Черный"
    }
  ]
}
```

## 📁 Структура проекта

```
.
├── main.py                  # Главный файл приложения
├── config.py               # Конфигурация
├── requirements.txt        # Зависимости
├── .env                    # Переменные окружения
├── models/                 # Модели БД
│   ├── category.py
│   ├── product.py
│   ├── user.py
│   ├── order.py
│   └── order_item.py
├── schemas/                # Pydantic схемы
│   ├── category.py
│   ├── product.py
│   ├── user.py
│   └── order.py
├── routes/                 # API роуты
│   ├── auth.py
│   ├── categories.py
│   ├── products.py
│   └── orders.py
└── utils/                  # Утилиты
    ├── database.py
    └── auth.py
```

## 🔒 Безопасность

- Пароли хешируются с использованием bcrypt
- JWT токены для аутентификации
- Защита эндпоинтов заказов (только для авторизованных пользователей)

## 🗄 База данных

По умолчанию используется SQLite. Для использования PostgreSQL:

1. Установите PostgreSQL
2. Измените `DATABASE_URL` в `.env`:
```
DATABASE_URL=postgresql://user:password@localhost/clothing_store
```

## 🚂 Деплой (Hosting)

### ⚠️ Важно: Railway Trial Plan

Railway Trial план **НЕ позволяет** деплоить веб-сервисы бесплатно (только базы данных).

### 🌟 Рекомендуемые бесплатные альтернативы:

#### 🥇 **Render.com** (Лучший выбор)
```bash
# Быстрая подготовка
.\prepare-render.ps1
```

**Преимущества:**
- ✅ Полностью бесплатно (без карты)
- ✅ PostgreSQL включен
- ✅ 750 часов/месяц
- ✅ Автоматический HTTPS

**Деплой:**
1. Загрузите на GitHub: `.\upload-to-github.ps1`
2. https://render.com → New Web Service
3. Подключите репозиторий `abubakr2545-lab/magazin`
4. Следуйте инструкциям из файла `RENDER_DEPLOY.md`

---

#### 🥈 **Fly.io** (Не засыпает!)
```bash
# Установка CLI
powershell -Command "iwr https://fly.io/install.ps1 -useb | iex"

# Деплой
fly launch
```

**Преимущества:**
- ✅ НЕ засыпает (всегда активен)
- ✅ PostgreSQL бесплатно
- ✅ Быстрый

**Недостатки:**
- ⚠️ Требуется банковская карта (но не списывают)

---

#### 🥉 **Koyeb** (Простой)
1. https://app.koyeb.com
2. Create App → GitHub
3. Deploy!

**Преимущества:**
- ✅ 512 MB RAM
- ✅ НЕ засыпает
- ✅ Без карты

---

### 📚 Подробные инструкции

См. файлы:
- [FREE_DEPLOY_ALTERNATIVES.md](FREE_DEPLOY_ALTERNATIVES.md) - Полный список альтернатив
- [RENDER_DEPLOY.md](RENDER_DEPLOY.md) - Пошаговая инструкция для Render
- [RAILWAY_DEPLOY.md](RAILWAY_DEPLOY.md) - Если у вас платный Railway

### 📊 Сравнение платформ

| Платформа | RAM | БД | Засыпает? | Карта? | Сложность |
|-----------|-----|-----|-----------|---------|-----------|
| **Render** | 512MB | ✅ | Да (15 мин) | ❌ | ⭐ Легко |
| **Fly.io** | 256MB | ✅ | Нет | ⚠️ Да | ⭐⭐ Средне |
| **Koyeb** | 512MB | ✅ | Нет | ❌ | ⭐ Легко |

---

### 🚀 Быстрый старт для Render

```powershell
# 1. Подготовка
.\prepare-render.ps1

# 2. Загрузка на GitHub
.\upload-to-github.ps1

# 3. Деплой на Render.com
# - Зайдите на https://render.com
# - New Web Service → GitHub
# - Выберите репозиторий
# - Следуйте инструкциям из RENDER_DEPLOY.md
```


---

## 📝 Лицензия

MIT
