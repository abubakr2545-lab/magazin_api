# 📤 Загрузка проекта на GitHub

## 🎯 Репозиторий
https://github.com/abubakr2545-lab/magazin.git

---

## 🚀 Быстрая загрузка (Автоматический скрипт)

Откройте PowerShell в папке проекта и выполните:

```powershell
.\upload-to-github.ps1
```

Скрипт автоматически:
- ✅ Покажет текущую конфигурацию Git
- ✅ Предложит изменить учетные данные
- ✅ Очистит кэш старого аккаунта GitHub
- ✅ Инициализирует Git (если нужно)
- ✅ Добавит remote на ваш репозиторий
- ✅ Создаст коммит
- ✅ Загрузит код на GitHub

---

## 🔑 Важно: Personal Access Token

GitHub больше не принимает пароли для git операций. Вам нужен **Personal Access Token**.

### Как создать токен:

1. Перейдите: https://github.com/settings/tokens/new
2. Название: `Magazin Project`
3. Expiration: `No expiration` (или выберите срок)
4. Выберите права (scopes):
   - ✅ `repo` (полный доступ к репозиториям)
5. Нажмите **Generate token**
6. **ВАЖНО**: Скопируйте токен! Он больше не будет показан!

### При загрузке на GitHub:

```
Username: abubakr2545-lab
Password: <ваш Personal Access Token>
```

**НЕ вводите пароль от аккаунта! Только токен!**

---

## 🛠️ Ручная загрузка (если нужно)

### Шаг 1: Очистка старых учетных данных

```powershell
# Очистить кэш Windows
cmdkey /delete:git:https://github.com

# Очистить Git Credential Manager
git credential-manager-core erase https://github.com
```

### Шаг 2: Настройка Git

```powershell
# Установите свое имя и email
git config --global user.name "Ваше Имя"
git config --global user.email "ваш-email@example.com"

# Проверка
git config --global user.name
git config --global user.email
```

### Шаг 3: Инициализация Git

```powershell
cd "c:\Users\Sherzod\Downloads\Telegram Desktop\иномов проект"

# Инициализация
git init

# Добавление файлов
git add .

# Коммит
git commit -m "Initial commit"
```

### Шаг 4: Подключение к GitHub

```powershell
# Добавление remote
git remote add origin https://github.com/abubakr2545-lab/magazin.git

# Переименование ветки в main (если нужно)
git branch -M main

# Загрузка на GitHub
git push -u origin main
```

При запросе учетных данных:
- **Username**: `abubakr2545-lab`
- **Password**: `<ваш Personal Access Token>`

---

## 🔄 Обновление кода в будущем

После первой загрузки, для обновлений используйте:

```powershell
# Добавить изменения
git add .

# Коммит
git commit -m "Описание изменений"

# Загрузка
git push
```

---

## ❌ Возможные ошибки и решения

### Ошибка: "remote: Repository not found"

**Причины**:
- Репозиторий не существует
- Неправильное название репозитория
- Нет доступа к репозиторию

**Решение**:
1. Проверьте, существует ли репозиторий: https://github.com/abubakr2545-lab/magazin
2. Убедитесь, что у вас есть права на запись

### Ошибка: "Authentication failed"

**Причина**: Неверные учетные данные или используется пароль вместо токена

**Решение**:
1. Создайте Personal Access Token (см. выше)
2. Используйте токен вместо пароля
3. Очистите кэш учетных данных и попробуйте снова

### Ошибка: "Updates were rejected"

**Причина**: В удаленном репозитории есть файлы, которых нет локально

**Решение**:
```powershell
# Загрузить изменения с GitHub
git pull origin main --allow-unrelated-histories

# Затем загрузить свои изменения
git push -u origin main
```

---

## 📋 Проверка после загрузки

1. Откройте репозиторий: https://github.com/abubakr2545-lab/magazin
2. Убедитесь, что все файлы загружены
3. Проверьте, что `.env` НЕ загружен (он в `.gitignore`)

---

## 🚂 Следующий шаг: Railway

После загрузки на GitHub, можете деплоить на Railway:

```powershell
.\deploy-railway.ps1
```

Или через веб-интерфейс Railway:
1. https://railway.app → New Project
2. Deploy from GitHub repo
3. Выберите `abubakr2545-lab/magazin`

---

## 💡 Полезные команды Git

```powershell
git status              # Статус репозитория
git log                 # История коммитов
git remote -v           # Просмотр remote репозиториев
git branch              # Просмотр веток
git config --list       # Вся конфигурация Git
```

---

**Удачи! 🚀**
