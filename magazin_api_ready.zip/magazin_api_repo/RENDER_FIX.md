# Исправление ошибки деплоя на Render

## ❌ Проблема

```
error: failed to create directory `/usr/local/cargo/registry/cache/index.crates.io-1949cf8c6b5b557f`
Caused by: Read-only file system (os error 30)
```

Эта ошибка возникала из-за:
1. Использование Python 3.13 (очень новая версия)
2. Старые версии пакетов не имели предкомпилированных колес для Python 3.13
3. pydantic-core пытался скомпилировать Rust код, но не мог из-за ограничений файловой системы

## ✅ Решение

### 1. Обновлены версии зависимостей

```diff
- fastapi==0.104.1
+ fastapi==0.115.6

- uvicorn[standard]==0.24.0
+ uvicorn[standard]==0.34.0

- sqlalchemy==2.0.23
+ sqlalchemy==2.0.36

- pydantic==2.5.0
+ pydantic==2.10.5

- pydantic-settings==2.1.0
+ pydantic-settings==2.7.1

- python-multipart==0.0.6
+ python-multipart==0.0.20

- alembic==1.12.1
+ alembic==1.14.0

- python-dotenv==1.0.0
+ python-dotenv==1.0.1

+ psycopg2-binary==2.9.10  # Для PostgreSQL
```

### 2. Изменена версия Python

```diff
- python-3.13.4
+ python-3.11
```

Python 3.11 более стабилен и все пакеты имеют для него предкомпилированные колеса.

### 3. Добавлен psycopg2-binary

Для работы с PostgreSQL на Render необходим `psycopg2-binary`.

## 🚀 Следующие шаги

1. **Закоммитьте изменения и загрузите на GitHub**:
   ```powershell
   git add requirements.txt runtime.txt
   git commit -m "Fix: Update dependencies for Python 3.11 compatibility"
   git push
   ```

2. **Render автоматически запустит новый деплой**

3. **Или вручную**: Dashboard → Manual Deploy → Deploy latest commit

## 📊 Проверка

После успешного деплоя проверьте:
- https://ваш-сервис.onrender.com/health
- https://ваш-сервис.onrender.com/docs

---

## 💡 Почему это работает?

### Предкомпилированные колеса (wheels)

Новые версии пакетов имеют предкомпилированные `.whl` файлы для Python 3.11, поэтому:
- ✅ Не нужна компиляция Rust
- ✅ Быстрая установка
- ✅ Нет проблем с файловой системой

### Python 3.11 vs 3.13

Python 3.13 вышел недавно (октябрь 2024), поэтому:
- ⚠️ Не все пакеты имеют готовые колеса
- ⚠️ Может потребоваться компиляция из исходников

Python 3.11:
- ✅ Стабильная версия
- ✅ Полная поддержка всех пакетов
- ✅ Рекомендуется для production

---

## 🔧 Альтернативное решение (если проблемы остаются)

Если все еще возникают проблемы, можно указать Python 3.10:

```
# runtime.txt
python-3.10
```

Python 3.10 - самая стабильная версия для деплоя на Render.
