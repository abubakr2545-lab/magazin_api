# 🚀 Бесплатные альтернативы для деплоя FastAPI

## 🌟 Лучшие бесплатные платформы для деплоя

---

## 1️⃣ Render.com (⭐ РЕКОМЕНДУЕТСЯ)

### ✅ Преимущества:
- 750 часов бесплатно в месяц
- Автоматический HTTPS
- PostgreSQL база данных (бесплатно)
- Простая настройка
- Автоматический деплой из GitHub
- Нет ограничений на веб-сервисы (в отличие от Railway Trial)

### 📊 Лимиты:
- Сервис засыпает после 15 минут неактивности
- 512 MB RAM
- Медленный холодный старт (~30 сек)

### 🚀 Как деплоить:

1. **Создайте аккаунт**: https://render.com
2. **New → Web Service**
3. **Подключите GitHub репозиторий**: `abubakr2545-lab/magazin`
4. **Настройки**:
   - **Name**: `magazin-api`
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Plan**: `Free`

5. **Environment Variables** (добавьте):
   ```
   SECRET_KEY=<сгенерированный-ключ>
   ALGORITHM=HS256
   ACCESS_TOKEN_EXPIRE_MINUTES=30
   ALLOWED_ORIGINS=https://ваш-фронтенд.com
   ```

6. **Добавьте PostgreSQL**:
   - New → PostgreSQL
   - Скопируйте `Internal Database URL`
   - Добавьте как переменную `DATABASE_URL`

7. **Deploy!**

### 📝 Нужные файлы (уже есть):
- ✅ `requirements.txt`
- ✅ `main.py`

---

## 2️⃣ Fly.io (⭐ ОЧЕНЬ ХОРОШО)

### ✅ Преимущества:
- НЕ засыпает (всегда активен!)
- Быстрый
- PostgreSQL бесплатно
- 3 VM бесплатно
- 160 GB трафика/месяц

### 📊 Лимиты:
- Требуется банковская карта (но НЕ списывают деньги)
- 256 MB RAM на бесплатном плане

### 🚀 Как деплоить:

```powershell
# 1. Установите Fly CLI
powershell -Command "iwr https://fly.io/install.ps1 -useb | iex"

# 2. Войдите (потребуется карта)
fly auth login

# 3. Запустите деплой
fly launch

# 4. База данных
fly postgres create

# 5. Подключите БД
fly postgres attach <db-name>
```

Fly автоматически создаст `fly.toml` конфигурацию!

---

## 3️⃣ Vercel (для FastAPI - с ограничениями)

### ✅ Преимущества:
- Очень быстрый
- Автоматический SSL
- Отличная интеграция с GitHub

### ⚠️ Недостатки:
- Лучше подходит для Next.js
- FastAPI работает как serverless функции
- Ограничения на время выполнения (10 сек на бесплатном плане)
- НЕ подходит для постоянных соединений

### 🚀 Как деплоить:

Создайте `vercel.json`:
```json
{
  "builds": [
    {
      "src": "main.py",
      "use": "@vercel/python"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "main.py"
    }
  ]
}
```

Затем:
1. https://vercel.com → New Project
2. Import Git Repository
3. Deploy!

**📌 Примечание**: Vercel лучше для фронтенда, для FastAPI используйте Render или Fly.io

---

## 4️⃣ PythonAnywhere

### ✅ Преимущества:
- Специально для Python
- Простая настройка
- MySQL база данных бесплатно
- Консоль доступна

### 📊 Лимиты:
- Только HTTP (не HTTPS на бесплатном)
- Старые версии Python
- Ограниченный трафик

### 🚀 Как деплоить:

1. https://www.pythonanywhere.com → Sign Up
2. Web → Add a new web app
3. Manual Configuration → Python 3.10
4. В консоли:
   ```bash
   cd ~
   git clone https://github.com/abubakr2545-lab/magazin.git
   cd magazin
   pip install -r requirements.txt
   ```
5. Настройте WSGI файл

**📌 Примечание**: Требует ручной настройки, сложнее чем Render

---

## 5️⃣ Koyeb

### ✅ Преимущества:
- 512 MB RAM бесплатно
- Автоматический деплой из GitHub
- PostgreSQL бесплатно
- Не засыпает

### 📊 Лимиты:
- 2 сервиса максимум на бесплатном плане

### 🚀 Как деплоить:

1. https://app.koyeb.com → Sign Up
2. Create App → GitHub
3. Выберите репозиторий
4. Configure:
   - **Builder**: Dockerfile или Buildpack
   - **Run command**: `uvicorn main:app --host 0.0.0.0 --port 8000`
5. Add Database → PostgreSQL
6. Deploy!

---

## 6️⃣ Deta Space (Бесплатно навсегда!)

### ✅ Преимущества:
- Полностью бесплатно
- Простая настройка
- База данных включена
- Хорошая документация

### 📊 Лимиты:
- Ограниченная кастомизация
- Встроенная NoSQL база (не PostgreSQL)

### 🚀 Как деплоить:

```powershell
# 1. Установите Space CLI
iwr https://get.deta.dev/space.ps1 -useb | iex

# 2. Войдите
space login

# 3. Создайте проект
space new

# 4. Деплой
space push
```

**📌 Примечание**: Потребуется адаптация для NoSQL базы

---

## 7️⃣ Google Cloud Run (Бесплатный tier)

### ✅ Преимущества:
- 2 миллиона запросов в месяц бесплатно
- Масштабируемость
- Профессиональная инфраструктура

### 📊 Лимиты:
- Требуется банковская карта
- Сложная настройка

### 🚀 Как деплоить:

Создайте `Dockerfile`:
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD uvicorn main:app --host 0.0.0.0 --port $PORT
```

Затем используйте Google Cloud SDK для деплоя.

---

## 8️⃣ Heroku (Платный с 2022 года)

❌ **Больше НЕ бесплатный** - требуется $5-7/месяц

---

## 📊 Сравнительная таблица

| Платформа | RAM | БД | Засыпает? | Карта нужна? | Сложность |
|-----------|-----|-----|-----------|--------------|-----------|
| **Render** | 512MB | ✅ PostgreSQL | ✅ Да (15 мин) | ❌ Нет | ⭐ Легко |
| **Fly.io** | 256MB | ✅ PostgreSQL | ❌ Нет | ⚠️ Да | ⭐⭐ Средне |
| **Vercel** | - | ❌ Нет | ❌ Нет | ❌ Нет | ⭐⭐ Средне |
| **Koyeb** | 512MB | ✅ PostgreSQL | ❌ Нет | ❌ Нет | ⭐ Легко |
| **Deta** | - | ⚠️ NoSQL | ❌ Нет | ❌ Нет | ⭐ Легко |
| **GCP Run** | Настр. | ⚠️ Отдельно | По запросу | ⚠️ Да | ⭐⭐⭐ Сложно |

---

## 🎯 Мои рекомендации

### 🥇 **Лучший выбор: Render.com**
- Простая настройка
- Бесплатный PostgreSQL
- Не требует карту
- Отлично для начала

### 🥈 **Если не хотите засыпания: Fly.io**
- Всегда активен
- Быстрый
- PostgreSQL
- Нужна карта (но бесплатно)

### 🥉 **Если нужна простота: Koyeb**
- Похож на Render
- Не засыпает
- Хорошие лимиты

---

## 🚀 Пошаговая инструкция для Render

### 1. Подготовка проекта

Убедитесь, что у вас есть в репозитории:
- ✅ `requirements.txt`
- ✅ `main.py`

### 2. Регистрация на Render

1. Перейдите: https://render.com
2. Sign Up (можно через GitHub)
3. Подтвердите email

### 3. Создание Web Service

1. Dashboard → **New +** → **Web Service**
2. **Connect repository**: выберите `abubakr2545-lab/magazin`
3. Настройки:
   ```
   Name: magazin-api
   Environment: Python 3
   Region: Frankfurt (ближе к вам)
   Branch: main
   Build Command: pip install -r requirements.txt
   Start Command: uvicorn main:app --host 0.0.0.0 --port $PORT
   ```
4. **Instance Type**: Free
5. **Advanced** → Environment Variables:
   ```
   SECRET_KEY = <сгенерируйте: python -c "import secrets; print(secrets.token_urlsafe(32))">
   ALGORITHM = HS256
   ACCESS_TOKEN_EXPIRE_MINUTES = 30
   ALLOWED_ORIGINS = *
   ```

### 4. Добавление PostgreSQL

1. Dashboard → **New +** → **PostgreSQL**
2. Name: `magazin-db`
3. Database: `magazin`
4. User: `magazin_user`
5. Region: Frankfurt
6. Instance Type: Free
7. Create Database

### 5. Подключение БД к сервису

1. Откройте созданную БД
2. Скопируйте **Internal Database URL**
3. Перейдите в ваш Web Service
4. Environment → Add Environment Variable:
   ```
   DATABASE_URL = <вставьте Internal Database URL>
   ```

### 6. Деплой!

Render автоматически начнет деплой. Следите за логами.

### 7. Проверка

После деплоя ваш API будет доступен по адресу:
```
https://magazin-api.onrender.com
```

Проверьте:
- https://magazin-api.onrender.com/health
- https://magazin-api.onrender.com/docs

---

## ⚠️ Важные замечания

### SQLite → PostgreSQL

Ваш `config.py` должен использовать переменную `DATABASE_URL` из окружения. Это уже настроено!

### Холодный старт на Render

Первый запрос после засыпания может занять 30-60 секунд. Это нормально для бесплатного плана.

### Сохранение активности

Если хотите, чтобы сервис не засыпал, можете использовать cron-сервис для пинга:
- https://cron-job.org
- Пингуйте ваш `/health` каждые 10 минут

---

## 🆘 Помощь

Если возникнут проблемы:
1. Проверьте логи в Render Dashboard
2. Убедитесь, что все переменные окружения установлены
3. Проверьте, что `DATABASE_URL` правильный

---

## 📚 Полезные ссылки

- **Render Docs**: https://render.com/docs
- **Fly.io Docs**: https://fly.io/docs
- **Koyeb Docs**: https://www.koyeb.com/docs

---

**Удачи с деплоем! 🚀**
